
package listaenlazadasimple;


public class MetodsList {
    Nodo Start;
    Nodo End;

    public MetodsList() {
        Start = null;
        End = null;
    }
    
    public void insertarInicio(String note){
        Nodo nuevo = new Nodo(note, Start);
        Start = nuevo;
        if(End == null)
            End = Start;
    }
    public void insertarFinal(String note){
        Nodo nuevo = new Nodo(note, null);
        if(Start == null){
            End = nuevo;
            Start = End;
        }else {
            End.setSiguiente(nuevo);
            End = nuevo;
        }
            
    }
    public void eliminarInicio(){
        Start = Start.siguiente;
        }
    public String extraerInicio(){
        String note = Start.getNote();
        Start = Start.getSiguiente();
        if(Start == null){
            End = null;
            
        }
        return note;
    }
    public void mostrarLista(){
        Nodo temp = Start;
        
        while(temp != null){
            System.out.println(temp.getNote());
            temp = temp.siguiente;
        }
    }
}
