/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package listaenlazadasimple;

/**
 *
 * @author rrori
 */
public class ListaEnlazadaSimple {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MetodsList l = new MetodsList();
        
        l.insertarInicio("a");
        l.insertarInicio("b");
        l.insertarInicio("c");
        l.insertarInicio("d");
        l.insertarInicio("e");
        l.insertarInicio("f");
        l.insertarFinal("P");
        l.mostrarLista();
        System.out.println();
        
       
        l.eliminarInicio();
        l.mostrarLista();
        System.out.println();
        
        System.out.println(l.extraerInicio());
        System.out.println();
        l.mostrarLista();
        System.out.println();
        l.extraerInicio();
        l.mostrarLista();
        System.out.println();
        
        
    }
    
}
